package com.contact.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.contact.model.Contact;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactService{

    //fake list of contacts

    List<Contact> list = Arrays.asList(
            new Contact(1L, "Lee@gmail.com", "Lee", 101L),
            new Contact(2L, "John@gmail.com", "John", 102L),
            new Contact(3L, "Johnson@gmail.com", "Johnson", 103L),
            new Contact(4L, "sameer@gmail.com", "Sameer", 104L)
    );

    public List<Contact> getContactsOfUser(Long userId) {
        return list.stream()
        		.filter(contact -> contact.getUserId()
        				.equals(userId)).collect(Collectors.toList());
    }


	
}
