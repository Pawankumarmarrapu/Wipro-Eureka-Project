package com.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomUserServiceApplication.class, args);
	}

}
